# Runtime API Draft

## POST /authority
Creates or registers authority.

Required fields:
- decision_id
- owner
- intent
- scope
- constraints
- expiry
- status

## POST /compile
Compiles authority into an exact AEO.

AEO fields:
- intent
- scope
- validation
- target
- finality

## POST /validate
Returns VALID or NULL for the exact AEO.

## POST /execute
Executes only if the executed object hash equals the validated object hash.

## POST /proof
Records Proof-of-Transfer and closes the loop.

## GET /health
Returns service status.
