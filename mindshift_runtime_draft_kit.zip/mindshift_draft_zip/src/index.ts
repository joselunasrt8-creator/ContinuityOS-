import type { Env, DecisionArtifact, AEO } from "./types";
import { putAuthority, getAuthority, consumeAuthority } from "./services/registry";
import { compileAEO } from "./services/compiler";
import { validateAEO } from "./services/validator";
import { canonicalize, sha256Hex } from "./services/canonical";
import { recordProof } from "./services/proof-ledger";

function json(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { "content-type": "application/json" }
  });
}

async function readJson<T>(request: Request): Promise<T> {
  return (await request.json()) as T;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    if (url.pathname === "/health") {
      return json({ status: "ok", service: "mindshift-runtime-draft" });
    }

    if (request.method !== "POST") return json({ error: "method_not_allowed" }, 405);

    if (url.pathname === "/authority") {
      const authority = await readJson<DecisionArtifact>(request);
      if (!authority.decision_id || !authority.owner || !authority.intent) {
        return json({ status: "NULL", error: "authority_missing_required_fields" }, 400);
      }
      return json(await putAuthority(authority));
    }

    if (url.pathname === "/compile") {
      const body = await readJson<{ decision_id: string; proposed_aeo?: Partial<AEO> }>(request);
      const authority = await getAuthority(body.decision_id);
      if (!authority) return json({ status: "NULL", error: "authority_missing" }, 404);
      const aeo = compileAEO(authority, body.proposed_aeo);
      const aeo_hash = await sha256Hex(canonicalize(aeo as unknown as Record<string, unknown>));
      return json({ aeo, aeo_hash });
    }

    if (url.pathname === "/validate") {
      const body = await readJson<{ aeo: AEO }>(request);
      const authority = await getAuthority(body.aeo.validation.decision_id);
      return json(await validateAEO(body.aeo, authority));
    }

    if (url.pathname === "/execute") {
      const body = await readJson<{ aeo: AEO; validated_aeo_hash: string }>(request);
      const executed_hash = await sha256Hex(canonicalize(body.aeo as unknown as Record<string, unknown>));
      if (executed_hash !== body.validated_aeo_hash) {
        return json({ status: "NULL", error: "validated_object_mismatch" }, 409);
      }
      const authority = await getAuthority(body.aeo.validation.decision_id);
      const validation = await validateAEO(body.aeo, authority);
      if (validation.result !== "VALID") return json({ status: "NULL", validation }, 403);

      const execution_id = crypto.randomUUID();
      await consumeAuthority(body.aeo.validation.decision_id);

      return json({
        status: "EXECUTED_DRAFT",
        execution_id,
        aeo_hash: executed_hash,
        target: body.aeo.target,
        note: "No real external call is wired in this draft."
      });
    }

    if (url.pathname === "/proof") {
      const body = await readJson<{
        execution_id: string;
        decision_id: string;
        aeo_hash: string;
        target_system: string;
        target_action: string;
        proof_reference: unknown;
      }>(request);

      const proof = await recordProof({
        proof_id: crypto.randomUUID(),
        execution_id: body.execution_id,
        decision_id: body.decision_id,
        aeo_hash: body.aeo_hash,
        target_system: body.target_system,
        target_action: body.target_action,
        proof_reference: body.proof_reference as never,
        timestamp: new Date().toISOString()
      });

      return json({ status: "PROOF_RECORDED", proof });
    }

    return json({ error: "not_found" }, 404);
  }
};
