export type Json = null | boolean | number | string | Json[] | { [key: string]: Json };

export type RegistryState = "ACTIVE" | "EXPIRED" | "REVOKED" | "CONSUMED";

export interface Env {
  DB?: D1Database;
  SIGNING_SECRET?: string;
  GITHUB_TOKEN?: string;
  GITHUB_OWNER?: string;
  GITHUB_REPO?: string;
  GITHUB_WORKFLOW_ID?: string;
}

export interface DecisionArtifact {
  decision_id: string;
  owner: string;
  intent: string;
  scope: Record<string, Json>;
  constraints: Record<string, Json>;
  expiry: string | null;
  status: RegistryState;
}

export interface AEO {
  intent: string;
  scope: Record<string, Json>;
  validation: {
    decision_id: string;
    require_active_authority: boolean;
    require_exact_object_hash: boolean;
  };
  target: {
    system: string;
    action: string;
  };
  finality: {
    proof_required: boolean;
    proof_type: string;
  };
}

export interface ValidationResult {
  result: "VALID" | "NULL";
  reasons: string[];
  aeo_hash?: string;
  timestamp: string;
}
