import type { AEO, DecisionArtifact } from "../types";

export function compileAEO(authority: DecisionArtifact, proposed?: Partial<AEO>): AEO {
  return {
    intent: proposed?.intent ?? authority.intent,
    scope: proposed?.scope ?? authority.scope,
    validation: {
      decision_id: authority.decision_id,
      require_active_authority: true,
      require_exact_object_hash: true
    },
    target: proposed?.target ?? {
      system: "github_actions",
      action: "deploy_workflow_dispatch"
    },
    finality: proposed?.finality ?? {
      proof_required: true,
      proof_type: "deployment_receipt"
    }
  };
}
