import type { DecisionArtifact } from "../types";

const memory = new Map<string, DecisionArtifact>();

export async function putAuthority(authority: DecisionArtifact): Promise<DecisionArtifact> {
  memory.set(authority.decision_id, authority);
  return authority;
}

export async function getAuthority(decision_id: string): Promise<DecisionArtifact | null> {
  return memory.get(decision_id) ?? null;
}

export async function consumeAuthority(decision_id: string): Promise<void> {
  const current = memory.get(decision_id);
  if (current) memory.set(decision_id, { ...current, status: "CONSUMED" });
}
