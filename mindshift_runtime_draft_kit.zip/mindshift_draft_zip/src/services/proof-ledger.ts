import type { Json } from "../types";

export interface ProofRecord {
  proof_id: string;
  execution_id: string;
  decision_id: string;
  aeo_hash: string;
  target_system: string;
  target_action: string;
  proof_reference: Json;
  timestamp: string;
}

const proofs: ProofRecord[] = [];

export async function recordProof(proof: ProofRecord): Promise<ProofRecord> {
  proofs.push(proof);
  return proof;
}
