import type { AEO, DecisionArtifact, ValidationResult } from "../types";
import { canonicalize, sha256Hex } from "./canonical";

const AEO_KEYS = ["finality", "intent", "scope", "target", "validation"];

export async function validateAEO(aeo: AEO, authority: DecisionArtifact | null): Promise<ValidationResult> {
  const reasons: string[] = [];

  const keys = Object.keys(aeo).sort();
  if (JSON.stringify(keys) !== JSON.stringify(AEO_KEYS)) reasons.push("invalid_aeo_shape");
  if (!authority) reasons.push("authority_missing");
  if (authority && authority.status !== "ACTIVE") reasons.push("authority_not_active");
  if (authority && authority.decision_id !== aeo.validation.decision_id) reasons.push("authority_mismatch");
  if (!aeo.finality?.proof_required) reasons.push("proof_required_missing");
  if (!aeo.target?.system || !aeo.target?.action) reasons.push("target_missing");

  const aeo_hash = await sha256Hex(canonicalize(aeo as unknown as Record<string, unknown>));

  return {
    result: reasons.length === 0 ? "VALID" : "NULL",
    reasons,
    aeo_hash,
    timestamp: new Date().toISOString()
  };
}
